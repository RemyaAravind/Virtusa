# Angular Routing & Security Demo (Angular 18 - Standalone components)

This is a minimal CLI-like skeleton demonstrating:
- Basic Routing
- Auth (CanActivate) Guard
- Role-based Guard
- Route data
- Route params & query params
- Lazy-loaded admin routes (using dynamic import)

Files are in `src/app`. To run as a full Angular app you should have @angular/cli installed:

```bash
npm install
ng serve
```

This repository intentionally provides a small, focused source tree for learning. You may integrate into a generated Angular CLI project if needed.
